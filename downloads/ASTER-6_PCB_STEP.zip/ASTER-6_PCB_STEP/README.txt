ASTER-6 joint interface - standard mechanical CAD export

Open aster_joint_interface.step in FreeCAD, Fusion, SolidWorks, Onshape or
another STEP-capable CAD application. Units are millimetres. The PCB is
100 x 100 mm; fitted components extend overall height to approximately
11.54 mm. The native board plane is XY, with components on the +Z side.

This export includes the board, fitted stock 3D components, pads, tracks,
zones, inner copper, mask and silkscreen. Optional R14/R15 bodies are omitted
because those components are marked DNP. F1 has its real copper lands but
no fitted fuse body model; JP1 is a bare copper solder jumper.

For editable circuits, net names, electrical rules and fabrication outputs,
use the native KiCad project package. This STEP is for mechanical inspection.

provenance.json records the source-board hash, native export options,
independent CAD import, bounds, validity and privacy checks.
THIRD_PARTY_NOTICES.txt records the design and stock-library terms.
