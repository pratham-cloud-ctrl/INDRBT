INDRBT: PCB STEP for mechanical CAD inspection

Extract the archive and import indrbt_joint_interface.step into a CAD tool
supporting STEP AP214 solid geometry. The board measures 100 x 100 mm;
all mechanical coordinates use millimetres. This is a native KiCad export.

Use this geometry for visual placement, measurement and section inspection.
The editable circuit, nets, copper rules and component library context are
in the separate INDRBT_KiCad_Project.zip download.

The export includes fitted component bodies, tracks, pads, zones, inner copper,
mask and silkscreen. The optional R14/R15 component bodies are excluded; pads
remain. F1 has copper lands without a dedicated fuse body, and JP1 is bare
copper. Geometry validity does not establish physical fit or qualification.

Source: https://github.com/pratham-cloud-ctrl/INDRBT
Browser inspection: https://pratham-cloud-ctrl.github.io/INDRBT/
Engineering revision 1.2.0; distribution 28 October 2026.
