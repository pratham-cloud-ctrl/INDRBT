INDRBT engineering inspection download
Project owner: Pratham (pratham-cloud-ctrl).
Original project attribution: INDRBT project contributors; see the unmodified LICENSE.
Repository: https://github.com/pratham-cloud-ctrl/INDRBT
Browser explorer: https://pratham-cloud-ctrl.github.io/INDRBT/

This is an original educational digital project. Payload, repeatability,
hardware operation, production tolerances and functional safety were not
physically validated. Original project files retain the existing MIT license.
Third-party library data retains the existing notices in NOTICE.md.
This inspection download packages the committed INDRBT design. Identity labels were refreshed; engineering limits and original third-party notices remain applicable.
FILES.json records source paths and SHA-256 hashes without machine-specific paths.

OPEN THE EDITABLE ELECTRONICS
1. Extract the complete archive, preserving folders.
2. Install KiCad 10 with its standard symbol, footprint and optional 3D libraries.
3. Open KiCad/joint_interface.kicad_pro in KiCad Project Manager; open its
   schematic or PCB from there. The layout uses millimetres.
4. Keep fp-lib-table, sym-lib-table and INDRBT_Interface.pretty alongside the
   project. ${KIPRJMOD} resolves the supplied custom F1 land pattern.

NATIVE FILES
The .kicad_pro project settings, .kicad_sch schematic, .kicad_pcb routed board
and .kicad_dru rules are unchanged original project files. Placed schematic
symbols and PCB footprint geometry are embedded. No custom symbol collection
is required. The library tables use standard KiCad 10 environment variables
for stock libraries; those installed libraries are not redistributed here.
Native KiCad 10.0.6 was used for the saved project evidence.

BOARD AND REFERENCES
100 x 100 mm, four copper layers, 44 schematic components and 48 PCB footprints
(including four mounting holes). The PCB is a 5 V input / 3.3 V logic joint and
sensor interface for an external controller and motor drive. It is not the
motor-power stage or a complete robot controller. BOM/bom.csv records parts.
R14/R15 are DNP by default; JP1 is a copper jumper.

PDF/3D FORMATS
Reference/joint_interface.pdf: schematic for reading or printing.
Reference/pcb_layers.pdf: six-page native layer drawings.
Reference/pcb_3d.png: native KiCad board preview.
Reference/indrbt-joint-interface.glb: existing KiCad-generated GLTF 2 binary
mesh, in glTF metres. The board outline is 0.1 x 0.1 m. Import into a GLB-capable
3D application for appearance/placement inspection. GLB is a mesh, not an
editable routed PCB or exact solid STEP assembly. Native KiCad remains the
authoritative editor for copper, nets, pads and schematic connections.

The GLB includes 40 component bodies; DNP R14/R15 are excluded. The custom F1
fuse has no fitted 3D body model, and JP1 has no physical body model. All native
pads and copper remain in the PCB design. Standard model files are referenced
through ${KICAD10_3DMODEL_DIR}; install the standard 3D library to display them
in KiCad. The original KiCad library license/generated-file exception is
documented in NOTICE.md and Reference/THIRD_PARTY_NOTICES.txt.

SCOPE
This focused package supports circuit/layout inspection and optional editing.
Saved ERC/DRC/connectivity evidence has its stated digital scope. No physical
board, thermal/EMC qualification, motor system, firmware, certified functional
safety or manufacturing approval is implied. This is not a fabrication order.
