ASTER-6 engineering inspection download
Project owner: Pratham (pratham-cloud-ctrl).
Original project attribution: ASTER-6 project contributors; see the unmodified LICENSE.
Repository: https://github.com/pratham-cloud-ctrl/industrial-robot-arm-digital-twin
Browser explorer: https://aster-six-engineering-showcase.warmkiwi64.chatgpt.site/

This is an original educational digital project. Payload, repeatability,
hardware operation, production tolerances and functional safety were not
physically validated. Original project files retain the existing MIT license.
Third-party library data retains the existing notices in NOTICE.md.
No geometry or circuit changes were made to produce this inspection download.
FILES.json records source paths and SHA-256 hashes without machine-specific paths.

CONTENTS AND UNITS
- STEP/Assemblies/assembly_home.step: complete home-pose assembly, 54 solids.
- STEP/Individual_Parts/: all 54 component solid STEP files.
- STL/: matching home assembly and 54 individual triangle meshes.
- Drawings/: three interface drawings as SVG and one three-page PDF.
All mechanical CAD coordinates and drawing lengths are millimetres.

OPEN IN CAD
1. Extract the archive, preserving folders.
2. In your CAD application, use File > Open/Import and select
   STEP/Assemblies/assembly_home.step. Choose millimetres if prompted.
3. For one part, import its STEP file from Individual_Parts. Each part uses its
   local assembly-group frame. Loading all individual files at one origin does
   not recreate the positioned assembly; use the supplied assembly file instead.

STEP preserves boundary-representation solid geometry for CAD interchange.
These are solid exports, not editable feature histories or native mate systems.
STL contains approximate triangles and does not store units, materials, joint
transforms or parametric features. Select millimetres when importing STL.
Combined assembly meshes retain separate contacting bodies; they are not a
single fused printable manifold. Individual solid models can be edited with
the receiving application's direct-modeling tools.

THE MECHANISM
Six revolute joints follow axes Z-Y-Y-X-Y-X. The parallel gripper has 0-90 mm
clearance between its pads, with symmetric 45 mm jaw travel. Screw, motor,
gearbox and bearing envelopes locate concepts; their internals are simplified.
The original parametric construction is Python/Build123d, driven by
06_Complete_Project_Source/config/robot.yaml in the full repository.

INSPECTION LIMITS
The included drawings are dimensioned concept interfaces, not manufacturing
drawings. No toleranced fit, engaged screw thread, preload, contact physics,
continuous collision guarantee or hardware qualification is supplied.
Manual configurations outside recorded poses may collide.
