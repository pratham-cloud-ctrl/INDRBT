ASTER-6 engineering inspection download
Project owner: Pratham (pratham-cloud-ctrl).
Original project attribution: ASTER-6 project contributors; see the unmodified LICENSE.
Repository: https://github.com/pratham-cloud-ctrl/industrial-robot-arm-digital-twin
Browser explorer: https://aster-six-engineering-showcase.warmkiwi64.chatgpt.site/

This is an original educational digital project. Payload, repeatability,
hardware operation, production tolerances and functional safety were not
physically validated. Original project files retain the existing MIT license.
Third-party library data retains the existing notices in NOTICE.md.
No geometry or circuit changes were made to produce this inspection download.
FILES.json records source paths and SHA-256 hashes without machine-specific paths.

OPEN THE NATIVE ASSEMBLY
Extract the archive, then open Model/aster6_home.FCStd inside FreeCAD.
The file was independently inspected with FreeCAD 1.1.4. It contains 54 visible
valid single-solid objects in the home pose. Length coordinates are millimetres.

The object tree displays descriptive component labels, alongside their internal
Component01-Component54 names. Custom properties identify each component,
rigid group, assumed material and representation role. Motor/gearbox/bearing
parts are simplified envelopes rather than detailed purchased hardware.

WHAT IS EDITABLE
This is a native FreeCAD document containing exported solid geometry and
inspection metadata. It is not a sketch-based parametric feature tree.
Direct geometry edits are possible using appropriate FreeCAD tools. Save your
edits as a separate working copy. The original parametric construction lives
in the repository's Python/Build123d source and shared robot.yaml file.
Use the companion STEP/STL download for neutral CAD interchange and drawings.

No physics or joint mechanism simulation is embedded in this document. The
browser viewer supplies the recorded digital motion. Neither establishes
physical payload, repeatability or production readiness.
